//шаг 1

var optionalName : String? //= "Omlette"
var optionalCookTimeInMinutes : Int? = 15
var isUsing : Bool = true
var description : String = "A breakfast dish made with eggs and mil, with bacon"
var ingridients = ["Eggs", "Milk", "Bacon"]

var name = optionalName ?? "Unknown"
var cookTimeInMinutes = optionalCookTimeInMinutes ?? 0

var dish1 = (name, cookTimeInMinutes, isUsing, description, ingridients[0], ingridients[1], ingridients[2])
var dish2 = (name, cookTimeInMinutes, isUsing, description, ingridients[0], ingridients[1], ingridients[2])
var dish3 = (name, cookTimeInMinutes, isUsing, description, ingridients[0], ingridients[1], ingridients[2])

print("""
Today we're cooking \(name), which takes \(cookTimeInMinutes) minutes to cook. It's \(description) 
and just uses \(ingridients)
""")

//шаг 2

if name == "Omlette"
{
    cookTimeInMinutes = 15
}
else
{
    cookTimeInMinutes = 0
    print("We don't know \(name). We only know Omlette")
}

if isUsing
{
    print("\(name) is using!")
}
else
{
    print("\(name) is not using!")
}

if description.count == 0
{
    print("Dish hasn't description!")
    description = "Some dish"
}
else
{
    print("Dish has description - \(description)")
}

//массив
var dishes = [dish1, dish2]

dishes.append(dish3)                    //create
var dishExample = dishes[0].3           //read
dishes[0].3 = "Some other description"  //update
dishes.remove(at: 1)                    //delete

//словарь
var dishesDescriptions : [String : String] = ["Omlette" : dish1.3, "Banana" : dish2.3, "Eggs" : dish3.3]

dishesDescriptions["Milk"] = "White liquid"                 //create
var dishDescriptionExample = dishesDescriptions["Omlette"]  //read
dishesDescriptions["Omlette"] = "Some other description"    //update
dishesDescriptions.removeValue(forKey: "Banana")            //delete

dish1.1 = 14
dish2.1 = 16
dish3.1 = 18

//множество
var dishesCookTime : Set<Int> = [dish1.1, dish2.1]

dishesCookTime.insert(dish3.1)                              //create
var dishCookTimeExample = dishesCookTime.contains(dish1.1)  //read
dishesCookTime.update(with: dish3.1)                        //update
dishesCookTime.remove(dish2.1)                              //delete


//таблица сравнения основных коллекций

//взаимодействие с элементом
dishes[0].0 = "Salad"                               //массив
dishesDescriptions["Banana"] = "Tasty yellow fruit" //словарь
dishesCookTime.update(with: dish2.1)                //множество

//добавление
dishes.append(dish3)                          //массив
dishesDescriptions["NewElement"] = "New dish" //словарь
dishesCookTime.insert(dish3.1)                //множество

//удаление
dishes.remove(at: 1)                            //массив
dishesDescriptions.removeValue(forKey: "Milk")  //словарь
dishesCookTime.remove(dish2.1)                  //множество

//поиск
var numbers = [12, -4, 61, 128]
var countries : [String : String] = ["United States" : "USA", "Ukraine" : "UK", "Great Britain" : "GB"]
var names : Set<String> = ["John", "Mary", "Jane"]

var isContainsEight = numbers.contains(8)   //массив
var ukrainShortName = countries["Ukraine"]  //словарь
names.contains("John")                      //множество

//сортировка
print(numbers.sort())           //массив
print(countries.sorted(by: <))  //словарь
print(names.sorted())           //множество
