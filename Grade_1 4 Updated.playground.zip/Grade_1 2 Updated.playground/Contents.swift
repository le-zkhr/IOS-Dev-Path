//-----------------------//
//шаг 1                  //
//-----------------------//

var optionalName : String? //= "Omlette"
var optionalCookTimeInMinutes : Int? = 15
var isActive : Bool = true
var description : String = "A breakfast dish made with eggs and milk, with bacon"
var ingridients = ["Eggs", "Milk", "Bacon"]

var name = optionalName ?? "Unknown"
var cookTimeInMinutes = optionalCookTimeInMinutes ?? 0

@MainActor func getDish(_ dish : Int) -> (String, Int, Bool, String, String, String, String) {
    let totalDished = 3
    var dish1 = (name, cookTimeInMinutes, isActive, description, ingridients[0], ingridients[1], ingridients[2])
    var dish2 = (name, cookTimeInMinutes, isActive, description, ingridients[0], ingridients[1], ingridients[2])
    var dish3 = (name, cookTimeInMinutes, isActive, description, ingridients[0], ingridients[1], ingridients[2])
    
    switch dish {
    case 1:
        return dish1
    case 2:
        return dish2
    case 3:
        return dish3
    default:
        print("Всего блюд - \(totalDished), вы ввели \(dish)! Получите тогда первое")
        return dish1
    }
}

print("""
Today we're cooking \(name), which takes \(cookTimeInMinutes) minutes to cook. It's \(description) 
and just uses \(ingridients)
""")

//-----------------------//
//шаг 2                  //
//-----------------------//

if name == "Omlette" {
    cookTimeInMinutes = 15
} else {
    cookTimeInMinutes = 0
    print("We don't know \(name). We only know Omlette")
}

if isActive {
    print("\(name) is using!")
} else {
    print("\(name) is not using!")
}

if description.count == 0 {
    print("Dish hasn't description!")
    description = "Some dish"
} else {
    print("Dish has description - \(description)")
}

//массив
var dishes = [getDish(1), getDish(2)]

dishes.append(getDish(3))                    //create
var dishExample = dishes[0].3           //read
dishes[0].3 = "Some other description"  //update
dishes.remove(at: 1)                    //delete

//словарь
var dishesDescriptions : [String : String] =
["Omlette" : getDish(1).0, "Banana" : getDish(2).3, "Eggs" : getDish(3).3]

dishesDescriptions["Milk"] = "White liquid"                 //create
var dishDescriptionExample = dishesDescriptions["Omlette"]  //read
dishesDescriptions["Omlette"] = "Some other description"    //update
dishesDescriptions.removeValue(forKey: "Banana")            //delete

var newDish1 = getDish(1)
var newDish2 = getDish(2)
var newDish3 = getDish(3)

newDish1.1 = 13
newDish2.1 = 17
newDish3.1 = 21

//множество
var dishesCookTime : Set<Int> = [getDish(1).1, getDish(2).1]

dishesCookTime.insert(getDish(3).1)                              //create
var dishCookTimeExample = dishesCookTime.contains(getDish(1).1)  //read
dishesCookTime.update(with: getDish(3).1)                        //update
dishesCookTime.remove(getDish(2).1)                              //delete


//таблица сравнения основных коллекций

//взаимодействие с элементом
dishes[0].0 = "Salad"                               //массив
dishesDescriptions["Banana"] = "Tasty yellow fruit" //словарь
dishesCookTime.update(with: getDish(2).1)                //множество

//добавление
dishes.append(getDish(3))                          //массив
dishesDescriptions["NewElement"] = "New dish" //словарь
dishesCookTime.insert(getDish(3).1)                //множество

//удаление
dishes.remove(at: 1)                            //массив
dishesDescriptions.removeValue(forKey: "Milk")  //словарь
dishesCookTime.remove(getDish(2).1)                  //множество

//поиск
var numbers = [12, -4, 61, 128]
var countries : [String : String] = ["United States" : "USA", "Ukraine" : "UK", "Great Britain" : "GB"]
var names : Set<String> = ["John", "Mary", "Jane"]
var chars : Set<Character> = ["A", "B", "C", "D", "E", "F"]

var isContainsEight = numbers.contains(8)   //массив
var ukrainShortName = countries["Ukraine"]  //словарь
names.contains("John")                      //множество

//сортировка
print(numbers.sort())           //массив
print(countries.sorted(by: <))  //словарь
print(names.sorted())           //множество

//-----------------------//
//Шаг 3                  //
//-----------------------//

for var dish in dishes {
    dish.0 = "SomeDish"
    print(dish.0)
}

for description in dishesDescriptions {
    print("Dish '\(description.key)' is '\(description.value)'")
}

for country in countries {
    if country.key.count <= 8 {
        print("Country '\(country.key)' is short. It' name is '\(country.value)'")
    }
}

var number = 0
while number < numbers.count {
    print(numbers[number])
    number += 1
}

//добавил тьюплы блюд 1,2,3 в функцию, которая при вызове возвращает блюдо, соответ. параметру функции

//-----------------------//
//Шаг 4                  //
//-----------------------//

//массив
func isSalad(_ dishName: String) -> Bool {
    dishName == "Salad"
}

func findSalad(_ dishTuple: [(String, Int, Bool, String, String, String, String)], _ closure: (String) -> Bool) {
    for dish in dishTuple {
        if closure(dish.0) {
            print("Салат найден в списке!'")
            return
        }
    }
}

findSalad(dishes, isSalad)

//словарь
func isFits(_ countryName: String) -> Bool {
    countryName.first == "U"
}

var coincedences = 0

@MainActor func findCountriesWithU(_ countriesDictionary: [String: String], _ closure: (String) -> Bool) {
    for country in countriesDictionary {
        if closure(country.key) {
            coincedences += 1
        }
    }
    print("Найдено \(coincedences) стран(а/ы) начинающихся на букву 'U'")
}

findCountriesWithU(countries, isFits)

//множество
func isInSet(_ letter: Character, _ needed: Character) -> Bool {
    letter == needed
}

func findCharacterInSet(_ lettersSet: Set<Character>, _ closure: (Character, Character) -> Bool) {
    for letter in lettersSet {
        if closure(letter, neededLetter) {
            print("Буква '\(letter)' найдена в множестве")
            return
        }
        
        print("Буква не найдена!")
    }
}

let neededLetter : Character = "Z"
findCharacterInSet(chars, isInSet)

enum RecipeType: String {
    case appetizer = "закуска"
    case beverage = "напиток"
    case main = "главное блюдо"
    case side = "гарнир"
    case dessert = "дессерт"
}

enum CookTime: Int {
    case none = 0
    case instantly = 5
    case fast = 10
    case medium = 20
    case slow = 30
}

struct Recipe {
    var name: String
    var cookTime: CookTime
    var isUsing: Bool
    var type: RecipeType
    var ingridients: [String]
    
    func checkInSet(_ recipes: Set<String>) {
        for recipe in recipes {
            if (recipe == name) {
                print("Рецепт \(name) найден!")
                return
            }
        }
        
        print("Рецепт \(name) не найден!")
    }
    
    func checkForCookTime (_ cookTimes: [Int]) {
        for time in cookTimes {
            if (time == cookTime.rawValue) {
                print ("Под ваше расписание за \(time) минут вы приготовите \(name)!")
                return
            }
        }
        
        print ("Под ваше расписание ничего не найдено!")
    }
    
    func pickUpByIngridients (_ availableIngridients: [String]) {
        for needed in availableIngridients {
            if (needed == ingridients.first) {
                print("Под этот ингридиент мы нашли блюдо \(name)! Оно готовится из: \(ingridients)")
                return
            }
        }
        
        print( "Не удалось найти блюдо под ингридиент!")
    }
    
    func checkInComplexDinner (_ complexDinner: Dictionary<RecipeType, String>) {
        for (type, name) in complexDinner {
            if (type == self.type && name == self.name) {
                print("Блюдо \(self.name) подается в вашем обеде как \(self.type.rawValue)")
                return
            }
        }
        
        print("Блюда \(name) нет в вашем списке обеда!")
    }
}


let pizza = Recipe(name: "Пицца", cookTime: .medium, isUsing: true, type: .main, ingridients: ["тесто", "все, что под руку попадется"])

let recipes: Set<String> = ["Кокосовый напиток", "Куриный суп", "Котлеты с пюрешкой", "Чуррос", "Пицца"]

let cookTimes: [Int] = [5, 10, 20, 30]

let ingridientsArray: [String] = ["вода", "тесто", "томаты", "чеснок", "джем"]

let complexDinner: Dictionary<RecipeType, String> = [.main: "Пицца", .side: "Соус", .dessert: "Чизкейк", .beverage: "Молочный коктейль"]

pizza.checkInSet(recipes)
pizza.checkForCookTime(cookTimes)
pizza.pickUpByIngridients(ingridientsArray)
pizza.checkInComplexDinner(complexDinner)

print("\n")

class RecipeClass {
    var name: String
    var cookTime: CookTime
    var type: RecipeType
    var ingridients: [String]
    
    init(name: String, cookTime: CookTime, type: RecipeType, ingridients: [String]) {
        self.name = name
        self.cookTime = cookTime
        self.type = type
        self.ingridients = ingridients
    }
    
    func checkInSet(_ recipes: Set<String>) {
        for recipe in recipes {
            if (recipe == name) {
                print("Рецепт \(name) найден!")
                return
            }
        }
        
        print("Рецепт \(name) не найден!")
    }
    
    func checkForCookTime (_ cookTimes: [Int]) {
        for time in cookTimes {
            if (time == cookTime.rawValue) {
                print ("Под ваше расписание за \(time) минут вы приготовите \(name)!")
                return
            }
        }
        
        print ("Под ваше расписание ничего не найдено!")
    }
    
    func pickUpByIngridients (_ someIngridients: [String]) {
        for needed in someIngridients {
            if (needed == ingridients.first) {
                print("Под этот ингридиент мы нашли блюдо \(name)! Оно готовится из: \(ingridients)")
                return
            }
        }
        
        print( "Не удалось найти блюдо под ингридиент!")
    }
    
    func checkInComplexDinner (_ complexDinner: Dictionary<RecipeType, String>) {
        for (type, name) in complexDinner {
            if (type == self.type && name == self.name) {
                print("Блюдо \(self.name) подается в вашем обеде как \(self.type.rawValue)")
                return
            }
        }
        
        print("Блюда \(name) нет в вашем списке обеда!")
    }
}

let cheesecake = RecipeClass(name: "Чизкейк", cookTime: .slow, type: .dessert, ingridients: ["Печенье", "Начинка", "Украшения"])

cheesecake.checkForCookTime(cookTimes)
cheesecake.checkInSet(recipes)
cheesecake.pickUpByIngridients(ingridientsArray)
cheesecake.checkInComplexDinner(complexDinner)
