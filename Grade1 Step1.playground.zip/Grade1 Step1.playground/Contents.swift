var name : String = "Omlette"
var cookTimeInMinutes : Int = 15
var isUsing : Bool = true
var description : String = "A breakfast dish made with eggs and mil, with bacon"
var firstIngridient : String = "eggs"
var secondIngridient : String = "milk"
var thirdIngridient : String = "bacon"

let dish = (name, cookTimeInMinutes, isUsing, description, firstIngridient, secondIngridient, thirdIngridient)

print("""
Today we're cooking \(dish.0), which takes \(dish.1) minutes to cook. It's \(dish.3) and just uses \(dish.4), \(dish.5) and \(dish.6).
""")
