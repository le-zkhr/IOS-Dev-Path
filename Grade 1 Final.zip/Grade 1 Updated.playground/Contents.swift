//-----------------------//
//Шаг 8                  //
//-----------------------//

enum Errors: String {
    case INVALID_VALUE = "Передано неверное значение!"
    case INVALID_INDEX = "Переданный индекс больше или меньше длины массива:"
    case VALUE_ALREADY_EXISTS = "Значение уже существует:"
    case EMPTY_ARRAY = "Массив пуст:"
    case VALUE_NOT_FOUND = "Значение не найдено в коллекции:"
}

//-----------------------//
//шаг 1                  //
//-----------------------//
print("=========ШАГ 1=========\n") //Для разделения вывода в консоли

var optionalName : String? = "Омлет"
var optionalCookTimeInMinutes : Int? = 15
var isActive : Bool = true //updated
var description : String = "Простое блюдо из молока и яиц."
var ingredients = ["Яйца", "Молоко", "Бекон"]

var name = optionalName ?? "Неизвестное блюдо"
var cookTimeInMinutes = optionalCookTimeInMinutes ?? 0

@MainActor func getDish(_ dish : Int) -> (String, Int, Bool, String, String, String, String) {
    let totalDished = 3
    var dish1 = (name, cookTimeInMinutes, isActive, description, ingredients[0], ingredients[1], ingredients[2])
    var dish2 = (name, cookTimeInMinutes, isActive, description, ingredients[0], ingredients[1], ingredients[2])
    var dish3 = (name, cookTimeInMinutes, isActive, description, ingredients[0], ingredients[1], ingredients[2])
    
    switch dish {
    case 1:
        return dish1
    case 2:
        return dish2
    case 3:
        return dish3
    default:
        print(Errors.INVALID_VALUE.rawValue, "Всего блюд - \(totalDished), вы ввели \(dish)! Получите тогда первое - \(dish1.0).")
        return dish1
    }
}

print("""
Сегодня приготовим '\(name)', которое займёт \(cookTimeInMinutes) минут для приготовления. 
Это \(description) 
Для него потребуются \(ingredients)
""")

//-----------------------//
//шаг 2                  //
//-----------------------//
print("\n=========ШАГ 2=========\n") //Для разделения вывода в консоли

var availableDish = "Омлет"

if name == availableDish {
    cookTimeInMinutes = 15
} else {
    cookTimeInMinutes = 0
    print("Блюда '\(name)' нет! Есть только \(availableDish)! Мужицкий \(availableDish)!!")
}

if isActive {
    print("\(name) активно!")
} else {
    print("\(name) неактивно!")
}

if description.count == 0 {
    print("Блюдо не имеет описания!")
    description = "Какое=то блюдо"
} else {
    print("Блюдо имеет описание - \(description)")
}

//массив
var dishes = [getDish(1), getDish(4)]

dishes.append(getDish(3))                   //create
var dishExample = dishes[0].3               //read
dishes[0].3 = "Какое-то другое описание"    //update
dishes.remove(at: 1)                        //delete

//словарь
var dishesDescriptions : [String : String] =
["Omlette" : getDish(1).0, "Banana" : getDish(2).3, "Eggs" : getDish(3).3]

dishesDescriptions["Milk"] = "Белая жидкость"               //create
var dishDescriptionExample = dishesDescriptions["Омлет"]    //read
dishesDescriptions["Omlette"] = "Какое-то описание"         //update
dishesDescriptions.removeValue(forKey: "Banana")            //delete

var newDish1 = getDish(1)
var newDish2 = getDish(2)
var newDish3 = getDish(3)

newDish1.1 = 13
newDish2.1 = 17
newDish3.1 = 21

//множество
var dishesCookTime : Set<Int> = [getDish(1).1, getDish(2).1]

dishesCookTime.insert(getDish(3).1)                              //create
var dishCookTimeExample = dishesCookTime.contains(getDish(1).1)  //read
dishesCookTime.update(with: getDish(3).1)                        //update
dishesCookTime.remove(getDish(2).1)                              //delete


//таблица сравнения основных коллекций

//взаимодействие с элементом
dishes[0].0 = "Salad"                                       //массив
dishesDescriptions["Banana"] = "Вкусный желтый фрукт"       //словарь
dishesCookTime.update(with: getDish(2).1)                   //множество

//добавление
dishes.append(getDish(3))                                   //массив
dishesDescriptions["NewElement"] = "Новое блюдо"            //словарь
dishesCookTime.insert(getDish(3).1)                         //множество

//удаление
dishes.remove(at: 1)                                        //массив
dishesDescriptions.removeValue(forKey: "Milk")              //словарь
dishesCookTime.remove(getDish(2).1)                         //множество

//поиск
var numbers = [12, -4, 61, 128]
var countries : [String : String] = ["United States" : "USA", "Ukraine" : "UK", "Great Britain" : "GB"]
var names : Set<String> = ["John", "Mary", "Jane"]
var chars : Set<Character> = ["A", "B", "C", "D", "E", "F"]

var isContainsEight = numbers.contains(8)   //массив
var ukrainShortName = countries["Ukraine"]  //словарь
names.contains("John")                      //множество

//сортировка
print(numbers.sort())                       //массив
print(countries.sorted(by: <))              //словарь
print(names.sorted())                       //множество

//-----------------------//
//Шаг 3                  //
//-----------------------//
print("\n=========ШАГ 3=========\n") //Для разделения вывода в консоли

for var dish in dishes {
    dish.0 = "Какое-то блюдо из dishes"
    print(dish.0)
}

print("\n")

for description in dishesDescriptions {
    print("Блюдо '\(description.key)' - '\(description.value)'")
}

print("\n")

for country in countries {
    if country.key.count <= 8 {
        print("Страна '\(country.key)' - короткая. Её название - '\(country.value)'")
    }
}

var number = 0
while number < numbers.count {
    print(numbers[number])
    number += 1
}

//добавил тьюплы блюд 1,2,3 в функцию, которая при вызове возвращает блюдо, соответ. параметру функции

//-----------------------//
//Шаг 4                  //
//-----------------------//
print("\n=========ШАГ 4=========\n") //Для разделения вывода в консоли

//массив
var neededDish = "Salad"

@MainActor func isSalad(_ dishName: String) -> Bool {
    dishName == neededDish
}

func findSalad(_ dishTuple: [(String, Int, Bool, String, String, String, String)], _ closure: (String) -> Bool) {
    for dish in dishTuple {
        if closure(dish.0) {
            print("Салат найден в списке!")
            return
        }
    }
    
    print("\(Errors.VALUE_NOT_FOUND.rawValue) салат в списке!")
}

findSalad(dishes, isSalad)

//словарь
var neededFirstLetter: Character = "U"

@MainActor func isFits(_ countryName: String) -> Bool {
    countryName.first == neededFirstLetter
}

var coincedences = 0

@MainActor func findCountriesWithU(_ countriesDictionary: [String: String], _ closure: (String) -> Bool) {
    for country in countriesDictionary {
        if closure(country.key) {
            coincedences += 1
        }
    }
    
    if (coincedences == 0) {
        print("\(Errors.VALUE_NOT_FOUND.rawValue) ни одной страны в словаре на букву 'U'!")
    } else {
        print("Найдено \(coincedences) стран(а/ы) начинающихся на букву 'U'")
    }
}

findCountriesWithU(countries, isFits)

//множество
func isInSet(_ letter: Character, _ needed: Character) -> Bool {
    letter == needed
}

@MainActor func findCharacterInSet(_ lettersSet: Set<Character>, _ closure: (Character, Character) -> Bool) {
    for letter in lettersSet {
        if closure(letter, neededFirstLetter) {
            print("Буква '\(letter)' найдена в множестве")
            return
        }
    }
    
    print("\(Errors.VALUE_NOT_FOUND.rawValue) буква \(neededFirstLetter) в множестве!")
} //updated

let neededLetter : Character = "Z"
findCharacterInSet(chars, isInSet)

enum RecipeType: String {
    case appetizer = "закуска"
    case beverage = "напиток"
    case main = "главное блюдо"
    case side = "гарнир"
    case dessert = "дессерт"
}

enum CookTime: Int {
    case none = 0
    case instantly = 5
    case fast = 10
    case medium = 20
    case slow = 30
}

//часть шага 6
protocol RecipeStructProtocol {
    var name: String { get }
    var cookTime: CookTime { get }
    var isActive: Bool { get }
    var type: RecipeType { get }
    var ingredients: [String] { get }
    
    func checkInSet(_ recipes: Set<String>)
    func checkForCookTime (_ cookTimes: [Int])
    func availableIngredients(_ someIngredients: [String])
    func checkInComplexDinner (_ complexDinner: Dictionary<RecipeType, String>)
}

protocol RecipeClassProtocol {
    func checkInSet(_ recipes: Set<String>)
    func checkForCookTime (_ cookTimes: [Int])
    func pickUpByIngredients (_ someIngredients: [String])
    func checkInComplexDinner (_ complexDinner: Dictionary<RecipeType, String>)
}
extension RecipeClassProtocol {
    //используются для демонстрации
//    private var name: String {
//        get { return "Unknown" }
//    }
//    private var cookTime: CookTime {
//        get { return .medium }
//    }
//    private var type: RecipeType {
//        get { return .main }
//    }
//    private var ingridients: [String] {
//        get { return [] }
//    }
}
//шаг 4 ниже

//структура как тип объекта. Хранит 5 свойств, имеет иниц-тор, 4 функции проверки для 4-х видов коллекций
struct RecipeStruct : RecipeStructProtocol {
    var name: String
    var cookTime: CookTime
    var isActive: Bool //updated
    var type: RecipeType
    var ingredients: [String]
    
    init(name: String, cookTime: CookTime, isActive: Bool, type: RecipeType, ingredients: [String]) {
        self.name = name
        self.cookTime = cookTime
        self.isActive = isActive
        self.type = type
        self.ingredients = ingredients
    }
    
    func checkInSet(_ recipes: Set<String>) {
        for recipe in recipes {
            if (recipe == name) {
                print("Рецепт \(name) найден!")
                return
            }
        }
        
        print("Рецепт \(name) не найден!")
    }
    
    func checkForCookTime (_ cookTimes: [Int]) {
        for time in cookTimes {
            if (time == cookTime.rawValue) {
                print ("Под ваше расписание за \(time) минут вы приготовите \(name)!")
                return
            }
        }
        
        print ("Под ваше расписание ничего не найдено!")
    }
    
    func availableIngredients(_ someIngredients: [String]) {
        let missingIngredients = ingredients.filter { !someIngredients.contains($0) }
        
        if missingIngredients.isEmpty {
            print("Вы можете приготовить блюдо \(name)! Оно готовится из: \(ingredients)")
        } else {
            print("Не хватает ингредиентов для приготовления \(name). Отсутствуют: \(missingIngredients)")
        }
    } //updated x 2
    
    func checkInComplexDinner (_ complexDinner: Dictionary<RecipeType, String>) {
        for (type, name) in complexDinner {
            if (type == self.type && name == self.name) {
                print("Блюдо \(self.name) подается в вашем обеде как \(self.type.rawValue)")
                return
            }
        }
        
        print("Блюда \(name) нет в вашем списке обеда!")
    }
}

let pizza = RecipeStruct(name: "Пицца", cookTime: .medium, isActive: true, type: .main, ingredients: ["тесто", "все, что под руку попадется"])

let recipes: Set<String> = ["Кокосовый напиток", "Куриный суп", "Котлеты с пюрешкой", "Чуррос", "Пицца"]

let cookTimes: [Int] = [5, 10, 20, 30]

let ingredientsArray: [String] = ["вода", "тесто", "томаты", "чеснок", "джем"]

let complexDinner: Dictionary<RecipeType, String> = [.main: "Пицца", .side: "Соус", .dessert: "Чизкейк", .beverage: "Молочный коктейль"]

pizza.checkInSet(recipes)
pizza.checkForCookTime(cookTimes)
pizza.availableIngredients(ingredientsArray)
pizza.checkInComplexDinner(complexDinner)

print("\n")

//класс как тип объекта. Хранит 4 других свойства, имеет иниц-тор, 4 функции проверки для 4-х видов коллекций
class RecipeClass : RecipeClassProtocol {
    private var name: String
    private var cookTime: CookTime
    private var type: RecipeType
    private var ingredients: [String]
    
    init(name: String, cookTime: CookTime, type: RecipeType, ingredients: [String]) {
        self.name = name
        self.cookTime = cookTime
        self.type = type
        self.ingredients = ingredients
    }
    
    func checkInSet(_ recipes: Set<String>) {
        for recipe in recipes {
            if (recipe == name) {
                print("Рецепт \(name) найден!")
                return
            }
        }
        
        print("Рецепт \(name) не найден!")
    }
    
    func checkForCookTime (_ cookTimes: [Int]) {
        for time in cookTimes {
            if (time == cookTime.rawValue) {
                print ("Под ваше расписание за \(time) минут вы приготовите \(name)!")
                return
            }
        }
        
        print ("Под ваше расписание ничего не найдено!")
    }
    
    func pickUpByIngredients (_ someIngredients: [String]) {
        for needed in someIngredients {
            if (needed == ingredients.first) {
                print("Под этот ингридиент мы нашли блюдо \(name)! Оно готовится из: \(ingredients)")
                return
            }
        }
        
        print( "Не удалось найти блюдо под ингридиент!")
    }
    
    func checkInComplexDinner (_ complexDinner: Dictionary<RecipeType, String>) {
        for (type, name) in complexDinner {
            if (type == self.type && name == self.name) {
                print("Блюдо \(self.name) подается в вашем обеде как \(self.type.rawValue)")
                return
            }
        }
        
        print("Блюда \(name) нет в вашем списке обеда!")
    }
}

let cheesecake = RecipeClass(name: "Чизкейк", cookTime: .slow, type: .dessert, ingredients: ["Печенье", "Начинка", "Украшения"])

cheesecake.checkForCookTime(cookTimes)
cheesecake.checkInSet(recipes)
cheesecake.pickUpByIngredients(ingredientsArray)
cheesecake.checkInComplexDinner(complexDinner)

//-----------------------//
//Шаг 6                  //
//-----------------------//

protocol Storage {
    func getName() -> String
    func setName(_ name: String)
    
    func getDescription() -> String?
    func setDescription(_ description: String?)
    func getRecipes() -> [RecipeStruct]
    func getLenght() -> Int
    func getLastRecipe() -> String?
    
    func createStorage(newName: String, newDesc: String?, recipes: [RecipeStruct]) -> RecipeStorageClass
    func showRecipes()
    func addRecipe(_ recipe: RecipeStruct)
    func checkForUniqueness(_ name: String) -> Bool
    func deleteRecipe(_ index: Int)
    func clearStorage()
    func sortByNames()
}
extension Storage {
    //используются для демонстрации
//    var name: String {
//        get { return "Пустое хранилище" }
//        set { }
//    }
//    var description: String? {
//        get { return nil }
//        set { }
//    }
//    var recipes: [RecipeStruct] {
//        get { return [] }
//    }
//    var lenght: Int {
//        get { return 0 }
//    }
//    var lastRecipe: String? {
//        get { return nil }
//    }
}

//-----------------------//
//Шаг 5                  //
//-----------------------//
print("\n=========ШАГ 5=========\n") //Для разделения вывода в консоли

//структура и класс хранилища выполняют одно и то же

//структура-хранилище для рецептов
struct RecipeStorageStruct {
    private var name: String {
        willSet(newName) {
            print("Название будет изменено с \(name) на \(newName)!")
        }
    }
    private var description: String? {
        didSet(newDesc) {
            print("Описание было изменено с \(description ?? "Пустое описание") на \(newDesc ?? "Пустое описание")!")
        }
    }
    private var recipes: [RecipeStruct] = []
    private var lenght: Int {
        return recipes.count
    }
    private var lastRecipe: String? {
        return recipes.last?.name ?? "Список пуст!" //updated
    }
    
    init(name: String, description: String?, recipes: [RecipeStruct]) {
        self.name = name
        self.description = description
        self.recipes = recipes
    }
    
    func getName() -> String {
        return name
    }
    mutating func setName(_ name: String) {
        self.name = name
    }
    
    func getDescription() -> String? {
        return description
    }
    mutating func setDescription(_ description: String?) {
        self.description = description
    }
    
    func getRecipes() -> [RecipeStruct] {
        return recipes
    }
    
    func getLenght() -> Int {
        return lenght
    }
    
    func getLastRecipe() -> String? {
        return lastRecipe
    }
    
    
    func createStorage(newName: String, newDesc: String?, recipes: [RecipeStruct]) -> RecipeStorageClass {
        print("Создано новое хранилище: '\(newName)'! Cодержит \(recipes.count) рецептов.\n")
        return RecipeStorageClass(name: newName, description: newDesc, recipes: recipes)
    } //create
    
    func showRecipes() {
        if recipes.isEmpty {
            print("\(Errors.EMPTY_ARRAY.rawValue) recipes!\n")
            return
        }
        
        print("Список рецептов в '\(name)':")
        recipes.forEach { print($0.name) }
        print("\n")
    } //read
    
    mutating func addRecipe(_ recipe: RecipeStruct) {
        if (checkForUniqueness(recipe.name)) { //updated
            print("Добавлен \(recipe.name)!\n")
            recipes.append(recipe)
        }
    } //update
    
    func checkForUniqueness(_ name: String) -> Bool {
        for recipe in recipes {
            if recipe.name == name {
                print("\(Errors.VALUE_ALREADY_EXISTS.rawValue)\(name)!\n")
                return false
            }
        }
        return true
    } //updated
    
    mutating func deleteRecipe(_ index: Int) { //updated x 2
        if index >= recipes.count {
            print("\(Errors.INVALID_INDEX.rawValue)\(index)!\n")
            return
        }
        else
        {
            print("Рецепт '\(recipes[index].name)' удален!\n")
            recipes.remove(at: index)
        }
    } //delete
    
    
    mutating func clearStorage() {
        print("Хранилище очищенно!\n")
        recipes.removeAll()
    }
    
    mutating func sortByNames() {
        print("Хранилище отсортировано по именам!\n")
        recipes.sort {$0.name < $1.name}
    }
}

//класс-хранилище для рецептов
class RecipeStorageClass : Storage {
    internal var name: String {
        willSet(newName) {
            print("Название будет изменено с \(name) на \(newName)!")
        }
    }
    private var description: String? {
        didSet(newDesc) {
            print("Описание было изменено с \(description ?? "Пустое описание") на \(newDesc ?? "Пустое описание")!")
        }
    }
    private var recipes: [RecipeStruct] = []
    private var lenght: Int {
        return recipes.count
    }
    private var lastRecipe: String? {
        return recipes.last?.name ?? "Список пуст!"
    }
    
    init(name: String, description: String?, recipes: [RecipeStruct]) {
        self.name = name
        self.description = description
        self.recipes = recipes
    }
    
    func getName() -> String {
        return name
    }
    func setName(_ name: String) {
        self.name = name
    }
    
    func getDescription() -> String? {
        return description
    }
    func setDescription(_ description: String?) {
        self.description = description
    }
    
    func getRecipes() -> [RecipeStruct] {
        return recipes
    }
    
    func getLenght() -> Int {
        return lenght
    }
    
    func getLastRecipe() -> String? {
        return lastRecipe
    }
    
    
    func createStorage(newName: String, newDesc: String?, recipes: [RecipeStruct]) -> RecipeStorageClass {
        print("Создано новое хранилище: '\(newName)'! Cодержит \(recipes.count) рецептов.\n")
        return RecipeStorageClass(name: newName, description: newDesc, recipes: recipes)
    } //create
    
    func showRecipes() {
        if recipes.isEmpty {
            print("\(Errors.EMPTY_ARRAY.rawValue) recipes!\n")
            return
        }
        
        print("Список рецептов в '\(name)':")
        recipes.forEach { print($0.name) }
        print("\n")
    } //read
    
    func addRecipe(_ recipe: RecipeStruct) {
        if (checkForUniqueness(recipe.name)) { //updated
            print("Добавлен \(recipe.name)!\n")
            recipes.append(recipe)
        }
    } //update
    
    func checkForUniqueness(_ name: String) -> Bool {
        for recipe in recipes {
            if recipe.name == name {
                print("\(Errors.VALUE_ALREADY_EXISTS.rawValue)\(name)!\n")
                return false
            }
        }
        return true
    }
    
    func deleteRecipe(_ index: Int) {
        if index >= recipes.count {
            print("\(Errors.INVALID_INDEX.rawValue)\(index)!\n")
            return
        }
        else
        {
            print("Рецепт '\(recipes[index].name)' удален!\n")
            recipes.remove(at: index)
        }
    } //delete
    
    
    func clearStorage() {
        print("Хранилище очищенно!\n")
        recipes.removeAll()
    }
    
    func sortByNames() {
        print("Хранилище отсортировано по именам!\n")
        recipes.sort {$0.name < $1.name}
    }
}

//переменные типа Recipe - наши рецепты
var recipeOne = RecipeStruct(name: "Печенье", cookTime: .medium, isActive: false, type: .dessert, ingredients: ["Молок", "Шоколад", "Сахар", "Яйца"])

var recipeTwo = RecipeStruct(name: "Печеная рыба", cookTime: .slow, isActive: true, type: .main, ingredients: ["Рыба", "Картофель", "Специи", "Соусы"])

var recipeThree = RecipeStruct(name: "Мохито", cookTime: .fast, isActive: false, type: .beverage, ingredients: ["Лайм", "Мята", "Спрайт", "Водка"])


//объект типа структуры-хранилища
var myStructStorage = RecipeStorageStruct(name: "Структурные Рецепты 1", description: "Мое хранилище-структура!", recipes: [])// [recipeOne, recipeTwo])

//демонстрация работы стуктуры-хранилища
print(myStructStorage.getLastRecipe() as Any)
print(myStructStorage.getLenght())
print(myStructStorage.getName())
print(myStructStorage.getDescription() ?? "Описание стурктуры-хранилища отсутствует!")
myStructStorage.setName("Хранилище-структура 01")
myStructStorage.setDescription(nil)

print("\n")

myStructStorage.showRecipes()
myStructStorage.addRecipe(recipeThree)
myStructStorage.showRecipes()
myStructStorage.deleteRecipe(0)
myStructStorage.sortByNames()
myStructStorage.showRecipes()
myStructStorage.clearStorage()
myStructStorage.getLastRecipe()


//объект типа класса-хранилища
let myClassStorage = RecipeStorageClass(name: "Классовые Рецепты 1", description: "Мое хранилище-класс", recipes: [recipeOne, recipeTwo])

//демонстрация работы класса-хранилища
print(myClassStorage.getLastRecipe() as Any)
print(myClassStorage.getLenght())
print(myClassStorage.getName())
print(myClassStorage.getDescription() ?? "Описание класса-хранилища отсутствует!")
print(myClassStorage.setName("Хранилище-класс 01"))
myClassStorage.setDescription(nil)

print("\n")

myClassStorage.showRecipes()
myClassStorage.addRecipe(recipeThree)
myClassStorage.showRecipes()
myClassStorage.deleteRecipe(0)
myClassStorage.sortByNames()
myClassStorage.showRecipes()
myClassStorage.clearStorage()
myClassStorage.getLastRecipe()
